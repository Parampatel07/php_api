package com.example.new1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
