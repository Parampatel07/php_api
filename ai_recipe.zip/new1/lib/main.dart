import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main(){
  runApp(const MaterialApp(
    home: Home(),
  ),);
}

class Home extends StatefulWidget{
  const Home({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => Homestate();
    // TODO: implement createState
    //Homestate();
    //throw UnimplementedError();


}
class Homestate extends State<Home>{
  File? imagefile;

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text("AI Recepie Maker"),
      ),

      body: Padding(padding: EdgeInsets.all(12.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if(imagefile != null)
              Container(
                height: 480,
                width: 640,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.black,
                  image: DecorationImage(
                      image: FileImage(imagefile!)
                  ),
                  border: Border.all(width: 8, color: Colors.deepOrange),
                  borderRadius: BorderRadius.circular(12.0),
                ),
              )
            else
            Container(
              height: 480,
              width: 640,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.black,
                border: Border.all(width: 8,color: Colors.deepOrange),
                borderRadius: BorderRadius.circular(12.0),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              children: [
                Expanded(child:
                ElevatedButton.icon(
                  onPressed: () => getimage(source: ImageSource.camera),
                  icon: Icon(Icons.camera_alt, size: 18),
                  label: Text("take photo"),
                )),
                SizedBox(
                  height: 20,
                ),
                Expanded(child:
                ElevatedButton.icon(
                  onPressed: ()=> getimage(source: ImageSource.gallery),
                  icon: Icon(Icons.image, size: 18),
                  label: Text("select photo"),
                )),
              ],
            )

          ],
        ),
      ),
    );



   // throw UnimplementedError();
  }
  void getimage({required ImageSource source} )async{

    final file = await ImagePicker().pickImage(source: source);
    if(file?.path != null){
      setState((){
        imagefile = File(file!.path);
      });
    }
  }
}