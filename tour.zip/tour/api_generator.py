import os

def create_files(file_data):
    for data in file_data:
        file_name = data['file_name']
        file_content = data['content']

        # Create the file and write the content
        with open(file_name, 'w') as file:
            file.write(file_content)

        print(f"File '{file_name}' created successfully.")

# Example usage
file_data_list = [
    {
        'file_name': 'delete_user.php',
        'content': '''<?php
/*
    Usage: Used to delete a user from the tour_user table

    How to call: http://localhost/api/tour/delete_user.php?userid=1

    Output:
    [{"error":"input is missing"}]
    [{"error":"no"},{"success":"yes"},{"message":"User deleted successfully"}]

    Input: userid (required)
*/

require_once 'connection.php';

$response = [];
$input = $_REQUEST;

if (isset($input['userid']) == false) {
    array_push($response, ['error' => 'Input is missing']);
} else {
    try {
        $sql = 'DELETE FROM tour_user WHERE userid = ?';
        $stat = $db->prepare($sql);
        $stat->bindParam(1, $input['userid']);
        $stat->execute();

        array_push($response, ['error' => 'no']);
        array_push($response, ['success' => 'yes']);
        array_push($response, ['message' => 'User deleted successfully']);
    } catch (PDOException $error) {
        array_push($response, ['error' => 'no']);
        array_push($response, ['success' => 'no']);
        array_push($response, ['message' => 'Invalid Request']);
    }
}

echo json_encode($response);
?>'''
    },
    {
        'file_name': 'delete_tour.php',
        'content': '''<?php
/*
    Usage: Used to delete a tour from the tour_tour table

    How to call: http://localhost/api/tour/delete_tour.php?tourid=1

    Output:
    [{"error":"input is missing"}]
    [{"error":"no"},{"success":"yes"},{"message":"Tour deleted successfully"}]

    Input: tourid (required)
*/

require_once 'connection.php';

$response = [];
$input = $_REQUEST;

if (isset($input['tourid']) == false) {
    array_push($response, ['error' => 'Input is missing']);
} else {
    try {
        $sql = 'DELETE FROM tour_tour WHERE tourid = ?';
        $stat = $db->prepare($sql);
        $stat->bindParam(1, $input['tourid']);
        $stat->execute();

        array_push($response, ['error' => 'no']);
        array_push($response, ['success' => 'yes']);
        array_push($response, ['message' => 'Tour deleted successfully']);
    } catch (PDOException $error) {
        array_push($response, ['error' => 'no']);
        array_push($response, ['success' => 'no']);
        array_push($response, ['message' => 'Invalid Request']);
    }
}

echo json_encode($response);
?>'''
    },
    {
        'file_name': 'delete_incomeexpense.php',
        'content': '''<?php
/*
    Usage: Used to delete an income or expense entry from the tour_incomeExpense table

    How to call: http://localhost/api/tour/delete_incomeexpense.php?incomeexpenseid=1

    Output:
    [{"error":"input is missing"}]
    [{"error":"no"},{"success":"yes"},{"message":"Income and expense entry deleted successfully"}]

    Input: incomeexpenseid (required)
*/

require_once 'connection.php';

$response = [];
$input = $_REQUEST;

if (isset($input['incomeexpenseid']) == false) {
    array_push($response, ['error' => 'Input is missing']);
} else {
    try {
        $sql = 'DELETE FROM tour_incomeExpense WHERE incomeexpenseid = ?';
        $stat = $db->prepare($sql);
        $stat->bindParam(1, $input['incomeexpenseid']);
        $stat->execute();

        array_push($response, ['error' => 'no']);
        array_push($response, ['success' => 'yes']);
        array_push($response, ['message' => 'Income and expense entry deleted successfully']);
    } catch (PDOException $error) {
        array_push($response, ['error' => 'no']);
        array_push($response, ['success' => 'no']);
        array_push($response, ['message' => 'Invalid Request']);
    }
}

echo json_encode($response);
?>'''
    },
    {
        'file_name': 'delete_booking.php',
        'content': '''<?php
/*
    Usage: Used to delete a booking from the tour_booking table

    How to call: http://localhost/api/tour/delete_booking.php?bookingid=1

    Output:
    [{"error":"input is missing"}]
    [{"error":"no"},{"success":"yes"},{"message":"Booking deleted successfully"}]

    Input: bookingid (required)
*/

require_once 'connection.php';

$response = [];
$input = $_REQUEST;

if (isset($input['bookingid']) == false) {
    array_push($response, ['error' => 'Input is missing']);
} else {
    try {
        $sql = 'DELETE FROM tour_booking WHERE bookingid = ?';
        $stat = $db->prepare($sql);
        $stat->bindParam(1, $input['bookingid']);
        $stat->execute();

        array_push($response, ['error' => 'no']);
        array_push($response, ['success' => 'yes']);
        array_push($response, ['message' => 'Booking deleted successfully']);
    } catch (PDOException $error) {
        array_push($response, ['error' => 'no']);
        array_push($response, ['success' => 'no']);
        array_push($response, ['message' => 'Invalid Request']);
    }
}

echo json_encode($response);
?>'''
    },
    {
        'file_name': 'delete_message.php',
        'content': '''<?php
/*
    Usage: Used to delete a message from the tour_message table

    How to call: http://localhost/api/tour/delete_message.php?messageid=1

    Output:
    [{"error":"input is missing"}]
    [{"error":"no"},{"success":"yes"},{"message":"Message deleted successfully"}]

    Input: messageid (required)
*/

require_once 'connection.php';

$response = [];
$input = $_REQUEST;

if (isset($input['messageid']) == false) {
    array_push($response, ['error' => 'Input is missing']);
} else {
    try {
        $sql = 'DELETE FROM tour_message WHERE messageid = ?';
        $stat = $db->prepare($sql);
        $stat->bindParam(1, $input['messageid']);
        $stat->execute();

        array_push($response, ['error' => 'no']);
        array_push($response, ['success' => 'yes']);
        array_push($response, ['message' => 'Message deleted successfully']);
    } catch (PDOException $error) {
        array_push($response, ['error' => 'no']);
        array_push($response, ['success' => 'no']);
        array_push($response, ['message' => 'Invalid Request']);
    }
}

echo json_encode($response);
?>'''
    },{
        'file_name': 'delete_alarm.php',
        'content': '''<?php
/*
    Usage: Used to delete an alarm from the tour_alarm table

    How to call: http://localhost/api/tour/delete_alarm.php?alarmid=1

    Output:
    [{"error":"input is missing"}]
    [{"error":"no"},{"success":"yes"},{"message":"Alarm deleted successfully"}]

    Input: alarmid (required)
*/

require_once 'connection.php';

$response = [];
$input = $_REQUEST;

if (isset($input['alarmid']) == false) {
    array_push($response, ['error' => 'Input is missing']);
} else {
    try {
        $sql = 'DELETE FROM tour_alarm WHERE alarmid = ?';
$stat = $db->prepare($sql);
$stat->bindParam(1, $input['alarmid']);
$stat->execute();
array_push($response, ['error' => 'no']);
    array_push($response, ['success' => 'yes']);
    array_push($response, ['message' => 'Alarm deleted successfully']);
} catch (PDOException $error) {
    array_push($response, ['error' => 'no']);
    array_push($response, ['success' => 'no']);
    array_push($response, ['message' => 'Invalid Request']);
}
}

echo json_encode($response);
?>
'''
},
{
'file_name': 'delete_photograph.php',
'content': '''<?php
/*
Usage: Used to delete a photograph from the tour_photograph table
How to call: http://localhost/api/tour/delete_photograph.php?photoid=1

Output:
[{"error":"input is missing"}]
[{"error":"no"},{"success":"yes"},{"message":"Photograph deleted successfully"}]

Input: photoid (required)
*/

require_once 'connection.php';

$response = [];
$input = $_REQUEST;

if (isset($input['photoid']) == false) {
array_push($response, ['error' => 'Input is missing']);
} else {
try {
$sql = 'DELETE FROM tour_photograph WHERE photoid = ?';
$stat = $db->prepare($sql);
$stat->bindParam(1, $input['photoid']);
$stat->execute();
array_push($response, ['error' => 'no']);
    array_push($response, ['success' => 'yes']);
    array_push($response, ['message' => 'Photograph deleted successfully']);
} catch (PDOException $error) {
    array_push($response, ['error' => 'no']);
    array_push($response, ['success' => 'no']);
    array_push($response, ['message' => 'Invalid Request']);
}
}

echo json_encode($response);
?>'''
}
]

create_files(file_data_list)