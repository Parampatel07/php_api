import os

def create_files(file_data):
    for data in file_data:
        file_name = data['file_name']
        file_content = data['content']

        # Create the file and write the content
        with open(file_name, 'w') as file:
            file.write(file_content)

        print(f"File '{file_name}' created successfully.")

# Example usage
file_data_list = file_data_list = [
    {
        'file_name': 'create_school_fee.php',
        'content': '''<?php
/*
    Usage: Used to create a new school fee
    How to call: http://localhost/api/school/create_school_fee.php?schoolid=1&title=Fee%20Title&amount=1000
    Output:
    [{"error":"input is missing"}]
    [{"error":"no"},{"success":"yes"},{"message":"School fee created successfully"}]
    Input: schoolid, title, amount (all required)
*/
require_once 'connection.php';
$response = [];
$input = $_REQUEST;
if (isset($input['schoolid'], $input['title'], $input['amount'])) {
    $sql = 'INSERT INTO school_fees (schoolid, title, amount) VALUES (?, ?, ?)';
    $stat = $db->prepare($sql);
    $stat->bindParam(1, $input['schoolid']);
    $stat->bindParam(2, $input['title']);
    $stat->bindParam(3, $input['amount']);
    $result = $stat->execute();
    if ($result) {
        array_push($response, ['error' => 'no']);
        array_push($response, ['success' => 'yes']);
        array_push($response, ['message' => 'School fee created successfully']);
    } else {
        array_push($response, ['error' => 'yes']);
        array_push($response, ['success' => 'no']);
        array_push($response, ['message' => 'Failed to create school fee']);
    }
} else {
    array_push($response, ['error' => 'input is missing']);
}
echo json_encode($response);
?>'''
    },
    {
        'file_name': 'read_school_fee.php',
        'content': '''<?php
/*
    Usage: Used to read school fee details
    How to call: http://localhost/api/school/read_school_fee.php?id=1
    Output:
    [{"error":"input is missing"}]
    [{"error":"no"},{"success":"yes"},{"data":{...}}]
    [{"error":"yes"},{"success":"no"},{"message":"School fee not found"}]
    Input: id (required)
*/
require_once 'connection.php';
$response = [];
$input = $_REQUEST;
if (isset($input['id'])) {
    $sql = 'SELECT * FROM school_fees WHERE id = ?';
    $stat = $db->prepare($sql);
    $stat->bindParam(1, $input['id']);
    $stat->execute();
    $school_fee = $stat->fetch(PDO::FETCH_ASSOC);
    if ($school_fee) {
        array_push($response, ['error' => 'no']);
        array_push($response, ['success' => 'yes']);
        array_push($response, ['data' => $school_fee]);
    } else {
        array_push($response, ['error' => 'yes']);
        array_push($response, ['success' => 'no']);
        array_push($response, ['message' => 'School fee not found']);
    }
} else {
    array_push($response, ['error' => 'input is missing']);
}
echo json_encode($response);
?>'''
    },
    {
        'file_name': 'update_school_fee.php',
        'content': '''<?php
/*
    Usage: Used to update a school fee
    How to call: http://localhost/api/school/update_school_fee.php?id=1&schoolid=1&title=New%20Fee%20Title&amount=2000
    Output:
    [{"error":"input is missing"}]
    [{"error":"no"},{"success":"yes"},{"message":"School fee updated successfully"}]
    [{"error":"yes"},{"success":"no"},{"message":"Failed to update school fee"}]
    Input: id, schoolid, title, amount (all required)
*/
require_once 'connection.php';
$response = [];
$input = $_REQUEST;
if (isset($input['id'], $input['schoolid'], $input['title'], $input['amount'])) {
    $sql = 'UPDATE school_fees SET schoolid = ?, title = ?, amount = ? WHERE id = ?';
    $stat = $db->prepare($sql);
    $stat->bindParam(1, $input['schoolid']);
    $stat->bindParam(2, $input['title']);
    $stat->bindParam(3, $input['amount']);
    $stat->bindParam(4, $input['id']);
    $result = $stat->execute();
    if ($result) {
        array_push($response, ['error' => 'no']);
        array_push($response, ['success' => 'yes']);
        array_push($response, ['message' => 'School fee updated successfully']);
    } else {
        array_push($response, ['error' => 'yes']);
        array_push($response, ['success' => 'no']);
        array_push($response, ['message' => 'Failed to update school fee']);
    }
} else {
    array_push($response, ['error' => 'input is missing']);
}
echo json_encode($response);
?>'''
    },
    {
        'file_name': 'delete_school_fee.php',
        'content': '''<?php
/*
    Usage: Used to delete a school fee
    How to call: http://localhost/api/school/delete_school_fee.php?id=1
    Output:
    [{"error":"input is missing"}]
    [{"error":"no"},{"success":"yes"},{"message":"School fee deleted successfully"}]
    [{"error":"yes"},{"success":"no"},{"message":"Failed to delete school fee"}]
    Input: id (required)
*/
require_once 'connection.php';
$response = [];
$input = $_REQUEST;
if (isset($input['id'])) {
    $sql = 'DELETE FROM school_fees WHERE id = ?';
    $stat = $db->prepare($sql);
    $stat->bindParam(1, $input['id']);
    $result = $stat->execute();
    if ($result) {
        array_push($response, ['error' => 'no']);
        array_push($response, ['success' => 'yes']);
        array_push($response, ['message' => 'School fee deleted successfully']);
    } else {
        array_push($response, ['error' => 'yes']);
        array_push($response, ['success' => 'no']);
        array_push($response, ['message' => 'Failed to delete school fee']);
    }
} else {
    array_push($response, ['error' => 'input is missing']);
}
echo json_encode($response);
?>'''
    },
    {
        'file_name': 'read_all_school_fees.php',
        'content': '''<?php
/*
    Usage: Used to read all school fees
    How to call: http://localhost/api/school/read_all_school_fees.php
    Output:
    [{"error":"no"},{"success":"yes"},{"data":[...]}]
*/
require_once 'connection.php';
$response = [];
$sql = 'SELECT * FROM school_fees';
$stat = $db->prepare($sql);
$stat->execute();
$school_fees = $stat->fetchAll(PDO::FETCH_ASSOC);
array_push($response, ['error' => 'no']);
array_push($response, ['success' => 'yes']);
array_push($response, ['data' => $school_fees]);
echo json_encode($response);
?>'''
    },
    {
        'file_name': 'read_school_fees_by_school.php',
        'content': '''<?php
/*
    Usage: Used to read school fees by school
    How to call: http://localhost/api/school/read_school_fees_by_school.php?schoolid=1
    Output:
    [{"error":"input is missing"}]
    [{"error":"no"},{"success":"yes"},{"data":[...]}]
    [{"error":"yes"},{"success":"no"},{"message":"No school fees found for the given school"}]
Input: schoolid (required)
*/
require_once 'connection.php';
$response = [];
$input = $_REQUEST;
if (isset($input['schoolid'])) {
$sql = 'SELECT * FROM school_fees WHERE schoolid = ?';
$stat = $db->prepare($sql);
$stat->bindParam(1, $input['schoolid']);
$stat->execute();
$school_fees = $stat->fetchAll(PDO::FETCH_ASSOC);
if ($school_fees) {
array_push($response, ['error' => 'no']);
array_push($response, ['success' => 'yes']);
array_push($response, ['data' => $school_fees]);
} else {
array_push($response, ['error' => 'yes']);
array_push($response, ['success' => 'no']);
array_push($response, ['message' => 'No school fees found for the given school']);
}
} else {
array_push($response, ['error' => 'input is missing']);
}
echo json_encode($response);
?>'''
}
]
create_files(file_data_list)